package com.example.android.erada2;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class registerActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private EditText regEmailText;
    private EditText regPassText;
    private EditText  regConfirmPassText;
    private Button register;
    private AHBottomNavigation bottomNavigation;
    private int item;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        progressBar = (ProgressBar) findViewById(R.id.regi_progressBar);
        regEmailText = (EditText) findViewById(R.id.register);
        regPassText = (EditText) findViewById(R.id.regi_pass);
        regConfirmPassText= (EditText) findViewById(R.id.regi_confirm);
        register = (Button) findViewById(R.id.reg_button);


        bottomNavigation = findViewById(R.id.bottom_navigation);

        AHBottomNavigationItem item1 = new AHBottomNavigationItem("إضافة جهة", R.drawable.add, R.color.items);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem("بحث باسم جهة", R.drawable.search_icon, R.color.items);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem("تعديل على جهة", R.drawable.edit, R.color.items);
        AHBottomNavigationItem item4 = new AHBottomNavigationItem( "الجهات", R.drawable.main , R.color.items);
        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.addItem(item4);
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.SHOW_WHEN_ACTIVE);
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));

        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                item = position;
                clickable();
                return true;
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = regEmailText.getText().toString();
                String pass = regPassText.getText().toString();
                String ConfirmPass = regConfirmPassText.getText().toString();

                if(!TextUtils.isEmpty(email) && !TextUtils.isEmpty(pass) && !TextUtils.isEmpty(ConfirmPass)){

                    if(pass.equals(ConfirmPass)){

                        progressBar.setVisibility(View.VISIBLE);
                        mAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {

                                if (task.isSuccessful()){

                                    Intent setupIntent = new Intent(registerActivity.this , FormActivity.class);
                                    startActivity(setupIntent);
                                }else {

                                    String errorMessage = task.getException().getMessage();
                                    Toast.makeText(registerActivity.this, "Error :"+errorMessage , Toast.LENGTH_LONG).show();
                                    finish();
                                }

                                progressBar.setVisibility(View.INVISIBLE);
                            }

                        });

                    }else {

                        Toast.makeText(registerActivity.this, "Confirm Password doesn't match the password .. Type again" , Toast.LENGTH_LONG).show();
                    }
                }

            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null){

            Intent intent = new Intent(registerActivity.this , FormActivity.class);
            startActivity(intent);

        }

    }
    private void clickable(){

        switch (item){
            case 0:
                Intent intent =new Intent(registerActivity.this , registerActivity.class);
                startActivity(intent);
                break;

            case 1:
                Intent intent1 =new Intent(registerActivity.this, searchActivity.class);
                startActivity(intent1);
                break;

            case 2:
                Intent intent2 =new Intent(registerActivity.this, LoginActivity.class);
                startActivity(intent2);
                break;

            case 3:
                Intent intent3 =new Intent(registerActivity.this, HomeActivity.class);
                startActivity(intent3);
                break;
            default:
                break;
        }
    }
}
