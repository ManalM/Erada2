package com.example.android.erada2;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

public class SchInfoActivity extends AppCompatActivity {
    private Button button;
    private ImageView InfoImage;
    private TextView InfoName , InfoAddress , InfoPhone , InfoDesc , InfoWebsite , InfoEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sch_info);

        InfoImage = (ImageView) findViewById(R.id.schInfo_image);
        InfoAddress = (TextView) findViewById(R.id.schInfo_address);
        InfoPhone = (TextView) findViewById(R.id.schInfo_phone);
        InfoDesc = (TextView) findViewById(R.id.schInfo_desc);
        InfoName = (TextView) findViewById(R.id.schInfo_name);
        InfoWebsite = (TextView) findViewById(R.id.schInfo_website);
        InfoEmail = (TextView) findViewById(R.id.schInfo_email);
        button = (Button) findViewById(R.id.button);

        final Intent intent = getIntent();


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!intent.getStringExtra("school_location").isEmpty()){

                Uri location = Uri.parse(intent.getStringExtra("school_location"));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);
                mapIntent.setPackage("com.google.android.apps.maps");
                try{
                startActivity(mapIntent);
                }
                catch (Exception e){
                    String message = e.getMessage();
                    Toast.makeText(SchInfoActivity.this,"Error:" + message , Toast.LENGTH_LONG).show();
                }
                }
                else {
                    Toast.makeText(SchInfoActivity.this , "لايوجد موقع ",Toast.LENGTH_SHORT).show();

                }

            }
        });

        InfoName.setText(intent.getStringExtra("school_name"));
        InfoAddress.setText(intent.getStringExtra("school_address"));
        InfoPhone.setText(intent.getStringExtra("school_phone"));
        InfoWebsite.setText(intent.getStringExtra("school_website"));
        InfoDesc.setText(intent.getStringExtra("school_description"));
        InfoEmail.setText(intent.getStringExtra("school_email"));
        Picasso.get().load(intent.getStringExtra("school_photo")).into(InfoImage);

        InfoEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailTo:"+intent.getStringExtra("center_email")));
                try{
                    startActivity(emailIntent);
                }catch (ActivityNotFoundException e ){
                    String message = e.getMessage();
                    Toast.makeText(SchInfoActivity.this,"Error:" + message , Toast.LENGTH_LONG).show();

                }

            }
        });
    }
}
