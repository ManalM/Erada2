package com.example.android.erada2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class searchActivity extends AppCompatActivity {

    private AHBottomNavigation bottomNavigation ;
    private int item;
    private EditText searchField;
    private ImageButton searchBtn;
    private RecyclerView recyclerView;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        databaseReference = FirebaseDatabase.getInstance().getReference("User");
        searchField = (EditText) findViewById(R.id.search_field);
        searchBtn = (ImageButton) findViewById(R.id.search_btn);
        recyclerView = (RecyclerView) findViewById(R.id.recycle_view);
        bottomNavigation = findViewById(R.id.bottom_navigation);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        AHBottomNavigationItem item1 = new AHBottomNavigationItem("إضافة جهة", R.drawable.add, R.color.items);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem("بحث باسم جهة", R.drawable.search_icon, R.color.items);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem("تعديل على جهة", R.drawable.edit, R.color.items);
        AHBottomNavigationItem item4 = new AHBottomNavigationItem("الجهات", R.drawable.main, R.color.items);
        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.addItem(item4);
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.SHOW_WHEN_ACTIVE);
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));
        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                item = position;
                clickable();
                return true;
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

             search();
            }
        });
    }
    private void clickable() {

        switch (item) {
            case 0:
                Intent intent = new Intent(searchActivity.this, registerActivity.class);
                startActivity(intent);
                break;

            case 1:
                Intent intent1 = new Intent(searchActivity.this, searchActivity.class);
                startActivity(intent1);
                break;

            case 2:
                Intent intent2 = new Intent(searchActivity.this, LoginActivity.class);
                startActivity(intent2);
                break;

            case 3:
                Intent intent3 = new Intent(searchActivity.this, HomeActivity.class);
                startActivity(intent3);
                break;
            default:
                break;
        }
    }

    public void search(){
        String  textSearch = searchField.getText().toString();
        Query firebaseSearch = databaseReference.orderByChild("name").orderByChild("address").startAt(textSearch).endAt(textSearch+"\"\\uf8ff\"");
        FirebaseRecyclerOptions queryOptions = new FirebaseRecyclerOptions.Builder<User>().setQuery(firebaseSearch, User.class).build();

        FirebaseRecyclerAdapter<User, UserViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<User,UserViewHolder>(
                queryOptions) {


            @Override
            protected void onBindViewHolder(@NonNull UserViewHolder holder, int position, @NonNull User model) {



               holder.setDetails(getApplicationContext(),model.getName(),model.getAddress(),model.getmImageResourceId());
            }

            @NonNull
            @Override
            public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.list_item, parent, false);

                return new UserViewHolder(view);
            }
        };

        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }
    public static class UserViewHolder extends RecyclerView.ViewHolder{
         View v;

        public UserViewHolder(View itemView) {
            super(itemView);
            v= itemView;
        }

    public void setDetails(Context ctx, String userName, String userStatus, String userImage) {

        TextView user_name = (TextView) v.findViewById(R.id.name_text_view);
        TextView user_address = (TextView) v.findViewById(R.id.address_text_view);
        ImageView user_image = (ImageView) v.findViewById(R.id.image);


        user_name.setText(userName);
        user_address.setText(userStatus);

        Glide.with(ctx).load(userImage).into(user_image);
    }
    }


}
