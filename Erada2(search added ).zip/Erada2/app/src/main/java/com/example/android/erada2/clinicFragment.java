package com.example.android.erada2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class clinicFragment extends Fragment {

    AHBottomNavigation bottomNavigation;

    private User user;
    private DatabaseReference databaseReference;
    private FirebaseDatabase database;
    private Toolbar toolbar;
    private ArrayList<User> arrayList;
    private UserAdapter adapter;
    private ListView list;

    private int item = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list, container, false);
      //  bottomNavigation=rootView.findViewById(R.id.bottom_navigation);
/*
        AHBottomNavigationItem item1 = new AHBottomNavigationItem("إضافة جهة", R.drawable.main, R.color.items);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem("بحث باسم جهة", R.drawable.search3, R.color.items);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem("تعديل على جهة", R.drawable.school, R.color.items);
        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.ALWAYS_SHOW);
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));

        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                item = position;
                clickable();
                return true;
            }
        });*/
        user = new User();
        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("User");

        list = (ListView) rootView.findViewById(R.id.list);

        arrayList = new ArrayList();
        adapter = new UserAdapter(getActivity(),R.layout.list_item,arrayList);
        databaseReference.child("clinic").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()){

                    user = data.getValue(User.class);
                    adapter.addElement(user);


                }
                list.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });




        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                User user = adapter.getItem(i);
                if (user != null){
                    Intent intent = new Intent(getActivity() , InfoActivity.class);
                    intent.putExtra("name",user.getName());
                    intent.putExtra("address", user.getAddress());
                    intent.putExtra("description",user.getDescription());
                    intent.putExtra("phone",user.getPhone());
                    intent.putExtra("website",user.getWebsite());
                    intent.putExtra("location" , user.getLocation());
                    intent.putExtra("email",user.getEmail());
                    intent.putExtra("photo",user.getmImageResourceId());
                    startActivity(intent);

                }

            }
        });

        return rootView;
    }
    private void clickable(){

        switch (item){
            case 0:
                Intent intent =new Intent(getActivity(), registerActivity.class);
                startActivity(intent);
                break;

            case 1:
                Intent intent1 =new Intent(getActivity() , searchActivity.class);
                startActivity(intent1);
                break;

            case 2:
                Intent intent2 =new Intent(getActivity() , LoginActivity.class);
                startActivity(intent2);
                break;

            default:
                break;
        }
    }
}
