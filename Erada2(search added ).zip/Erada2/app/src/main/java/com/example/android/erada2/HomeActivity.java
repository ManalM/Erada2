package com.example.android.erada2;

import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;

public class HomeActivity extends AppCompatActivity {


    private AHBottomNavigation bottomNavigation;
    private int item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        bottomNavigation = findViewById(R.id.bottom_navigation);

        AHBottomNavigationItem item1 = new AHBottomNavigationItem("إضافة جهة", R.drawable.add, R.color.items);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem("بحث باسم جهة", R.drawable.search_icon, R.color.items);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem("تعديل على جهة", R.drawable.edit, R.color.items);
        AHBottomNavigationItem item4 = new AHBottomNavigationItem( "الجهات", R.drawable.main , R.color.items);
        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.addItem(item4);
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.SHOW_WHEN_ACTIVE);
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));

        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {

                item = position;
                clickable();
                return true;
            }
        });
        // Create an adapter that knows which fragment should be shown on each page
        CategoryAdapter adapter = new CategoryAdapter(this, getSupportFragmentManager());

        // Set the adapter onto the view pager
        viewPager.setAdapter(adapter);

        // Find the tab layout that shows the tabs
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);

        // Connect the tab layout with the view pager. This will
        //   1. Update the tab layout when the view pager is swiped
        //   2. Update the view pager when a tab is selected
        //   3. Set the tab layout's tab names with the view pager's adapter's titles
        //      by calling onPageTitle()
        tabLayout.setupWithViewPager(viewPager);

    }

    private void clickable(){

        switch (item){
            case 0:
                Intent intent =new Intent(HomeActivity.this , registerActivity.class);
                startActivity(intent);
                break;

            case 1:
                Intent intent1 =new Intent(HomeActivity.this , searchActivity.class);
                startActivity(intent1);
                break;

            case 2:
                Intent intent2 =new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(intent2);
                break;

            case 3:
                Intent intent3 =new Intent(HomeActivity.this, HomeActivity.class);
                startActivity(intent3);
                break;
            default:
                break;
        }
    }
}
