package com.example.android.erada2;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.security.PrivateKey;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class InfoActivity extends AppCompatActivity {



    private Button InfoButton;
    private ImageView InfoImage;
    private TextView InfoName , InfoAddress , InfoPhone , InfoDesc , InfoWebsite , InfoEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        InfoImage = (ImageView) findViewById(R.id.Info_image);
        InfoAddress = (TextView) findViewById(R.id.Info_address);
        InfoPhone = (TextView) findViewById(R.id.Info_phone);
        InfoDesc = (TextView) findViewById(R.id.Info_desc);
        InfoName = (TextView) findViewById(R.id.Info_name);
        InfoWebsite = (TextView) findViewById(R.id.Info_website);
        InfoEmail = (TextView) findViewById(R.id.Info_email);
        InfoButton = (Button) findViewById(R.id.info_button);



         final Intent intent = getIntent();

            InfoButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(!intent.getStringExtra("location").isEmpty()){


                    Uri location = Uri.parse(intent.getStringExtra("location"));
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    try {
                        startActivity(mapIntent);
                    }catch (Exception e){
                        String message = e.getMessage();
                        Toast.makeText(InfoActivity.this,"Error:" + message , Toast.LENGTH_LONG).show();
                    }
                    }
                    else {
                        Toast.makeText(InfoActivity.this , "لايوجد موقع ",Toast.LENGTH_SHORT).show();
                    }

                }
            });


        InfoName.setText(intent.getStringExtra("name"));
        InfoAddress.setText(intent.getStringExtra("address"));
        InfoPhone.setText(intent.getStringExtra("phone"));
        InfoWebsite.setText(intent.getStringExtra("website"));
        InfoDesc.setText(intent.getStringExtra("description"));
        InfoEmail.setText(intent.getStringExtra("email"));
        Picasso.get().load(intent.getStringExtra("photo")).into(InfoImage);


       InfoEmail.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent emailIntent = new Intent(intent.ACTION_SENDTO);
               emailIntent.setData(Uri.parse("mailto:"+ intent.getStringExtra("email")));
               try {
                   startActivity(emailIntent);
               }catch (ActivityNotFoundException e){
                   String message = e.getMessage();
                   Toast.makeText(InfoActivity.this,"Error:" + message , Toast.LENGTH_LONG).show();
               }

           }
       });

}}
