package com.example.android.erada2;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private EditText regEmailText;
    private EditText regPassText;

    private Button register;
    private AHBottomNavigation bottomNavigation;
    private int item;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        progressBar = (ProgressBar) findViewById(R.id.login_progressBar);
        regEmailText = (EditText) findViewById(R.id.login);
        regPassText = (EditText) findViewById(R.id.login_pass);

        register = (Button) findViewById(R.id.log_button);

        bottomNavigation = findViewById(R.id.bottom_navigation);

        AHBottomNavigationItem item1 = new AHBottomNavigationItem("إضافة جهة", R.drawable.add, R.color.items);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem("بحث باسم جهة", R.drawable.search_icon, R.color.items);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem("تعديل على جهة", R.drawable.edit, R.color.items);
        AHBottomNavigationItem item4 = new AHBottomNavigationItem( "الجهات", R.drawable.main , R.color.items);
        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.addItem(item4);
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.SHOW_WHEN_ACTIVE);
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));

        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                item = position;
                clickable();
                return true;
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = regEmailText.getText().toString();
                String pass = regPassText.getText().toString();
                if(!TextUtils.isEmpty(email) && !TextUtils.isEmpty(pass)){


                    progressBar.setVisibility(View.VISIBLE);

                    mAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){


                                Intent intent = new Intent(LoginActivity.this , FormActivity.class);
                                startActivity(intent);
                            }else{
                                String errorMessage = task.getException().getMessage();
                                Toast.makeText(LoginActivity.this, "Error : " + errorMessage, Toast.LENGTH_LONG).show();


                            }
                            progressBar.setVisibility(View.INVISIBLE);
                        }
                    });
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currentUser= mAuth.getCurrentUser();
        if (currentUser!=null)
        {


            Intent intent = new Intent(LoginActivity.this , FormActivity.class);
            startActivity(intent);
        }
    }
    private void clickable(){

        switch (item){
            case 0:
                Intent intent =new Intent(LoginActivity.this , registerActivity.class);
                startActivity(intent);
                break;

            case 1:
                Intent intent1 =new Intent(LoginActivity.this, searchActivity.class);
                startActivity(intent1);
                break;

            case 2:
                Intent intent2 =new Intent(LoginActivity.this, LoginActivity.class);
                startActivity(intent2);
                break;

            case 3:
                Intent intent3 =new Intent(LoginActivity.this, HomeActivity.class);
                startActivity(intent3);
                break;
            default:
                break;
        }
    }
}
