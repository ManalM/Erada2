package com.example.android.erada2;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class CenInfoActivity extends AppCompatActivity {

    private Button InfoButton;
    private ImageView InfoImage;
    private TextView InfoName , InfoAddress , InfoPhone , InfoDesc , InfoWebsite , InfoEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cen_info);

        InfoImage = (ImageView) findViewById(R.id.cenInfo_image);
        InfoAddress = (TextView) findViewById(R.id.cenInfo_address);
        InfoPhone = (TextView) findViewById(R.id.cenInfo_phone);
        InfoDesc = (TextView) findViewById(R.id.cenInfo_desc);
        InfoName = (TextView) findViewById(R.id.cenInfo_name);
        InfoWebsite = (TextView) findViewById(R.id.cenInfo_website);
        InfoEmail = (TextView) findViewById(R.id.cenInfo_email);
        InfoButton = (Button) findViewById(R.id.cenInfo_location);

       final Intent intent = getIntent();

        InfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!intent.getStringExtra("center_location").isEmpty()){

                    Uri location = Uri.parse(intent.getStringExtra("center_location"));
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);
                    mapIntent.setPackage("com.google.android.apps.maps");
                try {
                    startActivity(mapIntent);
                }catch (Exception e){
                    String message = e.getMessage();
                    Toast.makeText(CenInfoActivity.this,"Error:" + message , Toast.LENGTH_LONG).show();
                }
                }
                else {
                    Toast.makeText(CenInfoActivity.this , "لايوجد موقع ",Toast.LENGTH_SHORT).show();

                }

            }
        });


        InfoName.setText(intent.getStringExtra("center_name"));
        InfoAddress.setText(intent.getStringExtra("center_address"));
        InfoPhone.setText(intent.getStringExtra("center_phone"));
        InfoWebsite.setText(intent.getStringExtra("center_website"));
        InfoDesc.setText(intent.getStringExtra("center_description"));
        InfoEmail.setText(intent.getStringExtra("center_email"));
        Picasso.get().load(intent.getStringExtra("center_photo")).into(InfoImage);


        InfoEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailTo:"+intent.getStringExtra("center_email")));
                try{
                    startActivity(emailIntent);
                }catch (ActivityNotFoundException e ){
                    String message = e.getMessage();
                    Toast.makeText(CenInfoActivity.this,"Error:" + message , Toast.LENGTH_LONG).show();

                }

            }
        });
    }
}
