package com.example.android.erada2;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import id.zelory.compressor.Compressor;

public class FormActivity extends AppCompatActivity {


    private TextView textView;
    private TextView textView1;
    private ImageView userImage;

    private EditText name_input;
    private EditText address_input;
    private EditText descrp_input;
    private EditText phone_input;
    private EditText email_input;
    private EditText location_input;
    private EditText website_input;

    private RadioGroup radioGroup;
    private RadioButton radioButton;

    private String userId;
    private User user;
    private DatabaseReference databaseReference;
    private FirebaseDatabase database;
    private FirebaseAuth mAuth;
    private Uri download_uri;
    private StorageReference storageReference;

    private Button register_btn;
    private Button logout;


    private Uri mainImageURI = null;

    private Boolean isChanged = false ;

    private Bitmap compressedImageFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        mAuth = FirebaseAuth.getInstance();

        user = new User();
        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("User");
        storageReference = FirebaseStorage.getInstance().getReference();

        final FirebaseUser userKey = mAuth.getCurrentUser();
        userId = userKey.getUid();


        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);

        name_input = (EditText) findViewById(R.id.name);
        address_input = (EditText) findViewById(R.id.address);
        descrp_input = (EditText) findViewById(R.id.descrition);
        location_input = (EditText) findViewById(R.id.location);
        website_input = (EditText) findViewById(R.id.website);
        phone_input = (EditText) findViewById(R.id.number);
        email_input = (EditText) findViewById(R.id.email);


        textView1 = (TextView) findViewById(R.id.category);
        textView = (TextView) findViewById(R.id.uploadImage);
        userImage = (ImageView) findViewById(R.id.userImage);

        register_btn = (Button) findViewById(R.id.register_btn);
        logout = (Button) findViewById(R.id.logout);

        int selectedId = radioGroup.getCheckedRadioButtonId();
        radioButton = (RadioButton) findViewById(selectedId);


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();

                Intent intent = new Intent(FormActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });
          /*
   ask permission and upload image
 */
        userImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    if (ContextCompat.checkSelfPermission(FormActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

                        Toast.makeText(FormActivity.this, "Permission Denied", Toast.LENGTH_LONG).show();
                        ActivityCompat.requestPermissions(FormActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);

                    } else {
                        BringImagePicker();
                    }

                } else {
                    BringImagePicker();
                }
            }
        });

        /*
         retrieve data from database
*/

        databaseReference.child("clinic").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    radioGroup.check(R.id.radioClinic);

                    if (data.exists()) {
                        user = dataSnapshot.getValue(User.class);
                        retrieveValue();
                    } else {
                        Toast.makeText(FormActivity.this, "لاتوجد بيانات للمستخدم", Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        databaseReference.child("center").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    radioGroup.check(R.id.radioCenter);

                    if (data.exists()) {

                        user = dataSnapshot.getValue(User.class);
                        retrieveValue();

                    } else {
                        Toast.makeText(FormActivity.this, "لاتوجد بيانات للمستخدم", Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        databaseReference.child("school").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    radioGroup.check(R.id.radioSchool);

                    if (data.exists()) {

                        user = dataSnapshot.getValue(User.class);
                        retrieveValue();

                    } else {
                        Toast.makeText(FormActivity.this, "لاتوجد بيانات للمستخدم", Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

register_btn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        if (mainImageURI != null ) {

            if (isChanged) {


            File newImageFile = new File(mainImageURI.getPath());
            try {


                compressedImageFile = new Compressor(FormActivity.this)
                        .compressToBitmap(newImageFile);

            } catch (IOException e) {
                e.printStackTrace();
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            compressedImageFile.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] thumbData = baos.toByteArray();

            UploadTask image_path = storageReference.child("profile_images").child(userId + ".jpg").putBytes(thumbData);

            image_path.addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                    if (task.isSuccessful()) {
                        storeData(task);

                    } else {

                        String error = task.getException().getMessage();
                        Toast.makeText(FormActivity.this, "خطأ في الصورة  " + error, Toast.LENGTH_LONG).show();
                    }
                }
            });
        }else {
            storeData(null);
                Toast.makeText(FormActivity.this, "تم تعديل المعلومات   " , Toast.LENGTH_LONG).show();
            }
        }
    }
});
    }


    /*

    METHODS
     */

    private void storeData(Task<UploadTask.TaskSnapshot> task) {

        //   Uri download_uri;

        if (task != null) {

            download_uri = storageReference.getDownloadUrl().getResult();
                 //   task.getResult().getDownloadUrl();

        } else {

            download_uri = mainImageURI;

        }

        user.setName(name_input.getText().toString());
        user.setAddress(address_input.getText().toString());
        user.setDescription(descrp_input.getText().toString());
        user.setLocation(location_input.getText().toString());
        user.setEmail(email_input.getText().toString());
        user.setPhone(phone_input.getText().toString());
        user.setWebsite(website_input.getText().toString());

        user.setmImageResourceId(download_uri.toString());
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                int id = radioGroup.getCheckedRadioButtonId();
                switch (id) {

                    case R.id.radioClinic:
                        databaseReference.child("clinic").child(userId).setValue(user);
                        break;

                    case R.id.radioCenter:
                        databaseReference.child("center").child(userId).setValue(user);
                        break;

                    default:
                        databaseReference.child("school").child(userId).setValue(user);
                        break;
                }

                 Toast.makeText(FormActivity.this, "تم حفظ المعلومات ", Toast.LENGTH_LONG).show();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }


    private void retrieveValue() {
        name_input.setText(user.getName());
        address_input.setText(user.getAddress());
        descrp_input.setText(user.getDescription());
        location_input.setText(user.getLocation());
        email_input.setText(user.getEmail());
        phone_input.setText(user.getPhone());
        website_input.setText(user.getWebsite());
        mainImageURI = Uri.parse(user.getmImageResourceId());
        //Picasso.get().load(mainImageURI).placeholder(R.drawable.defaul).into(userImage);

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.defaul);
        Glide.with(FormActivity.this).setDefaultRequestOptions(requestOptions).load(mainImageURI).into(userImage);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                mainImageURI = result.getUri();
                userImage.setImageURI(mainImageURI);

                  isChanged = true;

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                Exception error = result.getError();

            }
        }

    }


    private void BringImagePicker() {

        CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .setAspectRatio(1, 1)
                .start(FormActivity.this);
    }


}
